from django.shortcuts import render
from django.http import HttpResponse

def index(request):
	return render(request, "index.html")

def noticias(request):
	return render(request, "noticias.html")

def sobre(request):
	return render(request, "sobre.html")

def Disciplina(request):
	return render(request, "Disciplina.html")

def ListaDeCursos(request):
	return render(request, "ListaDeCursos.html")

def ads(request):
	return render(request, "ads.html")

def si(request):
	return render(request, "si.html")
	
def rc(request):
	return render(request, "rc.html")

def bd(request):
	return render(request, "bd.html")

def adm(request):
	return render(request, "adm.html")