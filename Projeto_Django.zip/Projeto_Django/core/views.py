from django.shortcuts import render
from django.http import HttpResponse

def index(request):
	return render(request, "index.html")

def noticias(request):
	return render(request, "noticias.html")

def DetalheDeCurso(request):
	return render(request, "DetalheDeCurso.html")

def Disciplina(request):
	return render(request, "Disciplina.html")

def ListaDeCursos(request):
	return render(request, "ListaDeCursos.html")

def ads(request):
	return render(request, "ads.html")

def si(request):
	return render(request, "si.html")