from django.contrib import admin
from django.urls import path
from core.views import *

urlpatterns = [
	path('', index),
    path('noticias.html', noticias),
    path('DetalheDeCurso.html', DetalheDeCurso),
    path('Disciplina.html', Disciplina),
    path('ListaDeCursos.html', ListaDeCursos),
    path('ads.html', ads),
    path('si.html', si),
    path('index.html',index),
    path('admin/', admin.site.urls),
]
