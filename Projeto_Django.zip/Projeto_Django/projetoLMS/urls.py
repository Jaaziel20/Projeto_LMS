from django.contrib import admin
from django.urls import path
from core.views import *

urlpatterns = [
	path('', index),
    path('noticias.html', noticias),
    path('sobre.html', sobre),
    path('Disciplina.html', Disciplina),
    path('ListaDeCursos.html', ListaDeCursos),
    path('ads.html', ads),
    path('si.html', si),
    path('rc.html', rc),
    path('bd.html', bd),
    path('adm.html', adm),
    path('index.html',index),
    path('admin/', admin.site.urls),
]
